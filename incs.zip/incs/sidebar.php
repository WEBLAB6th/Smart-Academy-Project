<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
        <img src="assets/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
            style="opacity: 0.8" />
        <span class="brand-text font-weight-light">Admin</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">



        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                            
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fa-solid fa-school"></i>
                        <p>
                            Students Details
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="apply_form_students_create.php" class="nav-link">
                              <i class="fa-solid fa-address-card"></i>
                                <p>Student Registration </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="apply_form_students_list.php" class="nav-link">
                                <i class="fas fa-users"></i>
                                <p>All Students</p>
                            </a>
                        </li>
                    </ul>
                </li>


                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="fa-solid fa-school"></i>
                        <p>
                            Teachers
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="teacher_registration.php" class="nav-link">
                                <i class="fas fa-chalkboard-teacher"></i>
                                <p>Teacher Registration</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="teacher_list.php" class="nav-link">
                                <i class="fab fa-teamspeak"></i>
                                <p>All Teachers</p>
                            </a>
                        </li>
                    </ul>
                </li>


                <li class="nav-item">
                    <a href="graduate_students_list.php" class="nav-link">
                        <i class="fa-solid fa-graduation-cap"></i>
                        <p>
                            Graduate Students List
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                </li>


                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <!-- <i class="fa-brands fa-discourse"></i> -->
                        <i class="fas fa-book"></i>
                        <p>
                            Courses
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="courses_create.php" class="nav-link">
                            <i class="fa-solid fa-book-open-reader"></i>
                                <p>Course Create</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="courses_list.php" class="nav-link">
                            <i class="fa-solid fa-bookmark"></i>
                                <p>All Courses</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                    <i class="fa-brands fa-slideshare"></i>
                        <p>
                            Slider
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="silder_create.php" class="nav-link">
                            <i class="fa-solid fa-sliders"></i>
                                <p>Slider Create</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="silder_list.php" class="nav-link">
                            <i class="fa-solid fa-hill-rockslide"></i>
                                <p>All Sliders</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                    <i class="fa-regular fa-address-book"></i>
                        <p>
                            Contact Us
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="contact_list.php" class="nav-link">
                            <i class="fa-solid fa-file-signature"></i>
                                <p>All Contacts</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                    <i class="fas fa-star"></i>
                        <p>
                            Reviews
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="reviews_list.php" class="nav-link">
                            <i style="font-size: 10px;" class="fas fa-star"></i>
                            <i style="font-size: 10px;" class="fas fa-star"></i> 
                                <p>All Reviews</p>
                            </a>
                        </li>
                        
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                          <i class="fas fa-camera"></i>
                        <p>
                            Gallery
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="gallery_create.php" class="nav-link">
                              <i class="fa-brands fa-envira"></i>
                                <p>Add Gallery</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="gallery_list.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>All Gallery</p>
                            </a>
                        </li>
                    </ul>
                </li>


            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>

