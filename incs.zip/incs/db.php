<?php 
    $con = NEW PDO("mysql:host=localhost;dbname=smart_academy;user=root;password=");
    if(!$con){
      Die("Database Is not properly Work Go check Your Database");
    }


?>