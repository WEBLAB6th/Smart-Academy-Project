<footer class="main-footer">

    <strong>Copyright &copy; 2023-2030
        <a href="../index.php">Smart Institute Of IT</a>.</strong>
    All rights reserved.
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="assets/js/adminlte.min.js"></script>
<script src="../assets/js/jquery.validate.min.js"></script>
<script src="https://kit.fontawesome.com/a0add6ad96.js" crossorigin="anonymous"></script>
<!-- AdminLTE for demo purposes -->

<script>
$(document).ready(function() {
    $.validator.addMethod("maxWords", function(value, element, params) {
        var wordCount = value.trim().split(/\s+/).length;
        return this.optional(element) || wordCount <= params;
    }, $.validator.format("Please enter {0} words."));
});
</script>
<script>
jQuery('#course').validate({

    rules: {
        course_name: {
            required: true,
            maxlength: 300,

        },
        course_description: {
            required: true,
            maxWords: 500,
        },
        fee: "required",
        image: {
            required: true,

        },
        status: "required",

    },
    messages: {
        course_name: {
            required: "Please enter a Course Name",
            maxlength: "Please enter at least 300 characters",
        },
        course_description: {
            required: "Please enter a Course Description",
            maxWords: "Please enter at least 500 words",
        },
        fee: "Enter Amount",

        image: {
            required: "Please Select a file",
        },
        status: "Please Enter the course Status",


    }

})

jQuery('#apply_form').validate({

    rules: {
        fname: {
            required: true,

        },
        lname: {
            required: true,

        },
        email: {
            required: true,
            email: true,
        },
        pnumber: {
            required: true,

        },
        address: "required",

        qualification: "required",

        fee: "required"

    },
    messages: {

        fname: {
            required: "Please enter your Name",

        },
        lname: {
            required: "Please enter your last Name",

        },


        email: {
            required: "Please Enter email",
            email: "Please enter a valid email address",
        },
        pnumber: {
            required: "Please Enter your Phone number",
        },

        address: "Please Enter Your Address",

        qualification: "please Enter your qualification",

        fee: "Enter Amount",


    }


})

jQuery('#Slider').validate({

    rules: {
        title: {
            required: true,

        },
        description: {
            required: true,
            maxWords: 500,

        },
        image: {
            required: true,
        }
    },
    messages: {

        title: {
            required: "Please enter Title",

        },
        description: {
            required: "Please enter Description",
            maxWords: "Please enter at least 500 words"

        },


        image: {
            required: "Please Select Image",

        }
    }


})



jQuery('#teacher_form').validate({

    rules: {
        fname: {
            required: true,

        },
        lname: {
            required: true,
            maxWords: 500,

        },
        father_name: {

            required: true,

        },
        email: {

            required: true,
            email: true,
        },
        address: {
            required: true,
        },
        experience: {
            required: true,
        },
        description: {
            required: true,
            maxWords: 500,

        },
        image: {
            required: true,
        },
        cv: {
            required: true,
        }
    },
    messages: {

        fname: {
            required: "Please enter your Name",

        },
        lname: {
            required: "Please enter your last Name",

        },
        father_name: {
            required: "Please enter your Father Name",

        },

        email: {
            required: "Please Enter email",
            email: "Please enter a valid email address",
        },
        address: {
            required: "Please enter your Address",

        },
        experience: {
            required: "Please enter your Address",

        },
        description: {
            required: "Please enter Description",
            maxWords: "Please enter at least 500 words"

        },

        image: {
            required: "Please Select Your Image",

        },
        cv: {
            required: "Please Select Your Cv",

        }
    }


})

jQuery('#certificate').validate({

    rules: {
        type_degree: {
            required: true,

        }
    },
    messages: {
        type_degree: {
            required: "Please Enter Certificate / Diploma",

        }
    }


})
</script>
<script>
function toggleDescription(button) {
    var paragraph = button.parentElement.querySelector('.description');
    var paragraphStyle = window.getComputedStyle(paragraph);

    if (paragraphStyle.maxHeight === '50px' || paragraphStyle.maxHeight === '') {
        paragraph.style.maxHeight = 'none';
        button.innerHTML = 'Read Less';
    } else {
        paragraph.style.maxHeight = '50px';
        button.innerHTML = 'Read More';
    }
}
</script>







<script>
function openCertificateModal(certificatePath) {
    document.getElementById('certificateModal').style.display = 'block';
    document.getElementById('certificateImage').src = 'uploads/' + certificatePath;
}

function closeCertificateModal() {
    document.getElementById('certificateModal').style.display = 'none';
}
</script>


<script>
function openReceiptModal(certificatePath) {
    document.getElementById('ReceiptModal').style.display = 'block';
    document.getElementById('ReceiptImage').src = 'uploads/' + certificatePath;
}

function closeReceiptModal() {
    document.getElementById('ReceiptModal').style.display = 'none';
}
</script>







<script>
function openimageModal(certificatePath) {
    document.getElementById('imageModal').style.display = 'block';
    document.getElementById('image').src = 'uploads/' + certificatePath;
}

function closeimageModal() {
    document.getElementById('imageModal').style.display = 'none';
}
</script>

<script>
$('#search').on("keyup", function() {
    var search_term = $(this).val();

    if (search_term.trim() === "") {
        $("#table-data").html("");
        return;
    }
    $.ajax({
        url: "live_search.php",
        method: "post",
        data: {
            search: search_term
        },
        success: function(data) {
            $("#table-data").html(data);
        }
    })
})
</script>

<script>
$('#search_cert').on("keyup", function() {
    var search_term = $(this).val();

    if (search_term.trim() === "") {
        $("#table-data").html("");
        return;
    }
    $.ajax({
        url: "live_search_graduate_data.php",
        method: "post",
        data: {
            search: search_term
        },
        success: function(data) {
            $("#table-data-cert").html(data);
        }
    })
})
</script>

<script>
function openVideoModal(videoURL) {
    var modal = document.getElementById('videoModal');
    var video = document.getElementById('video');
    video.src = videoURL;
    modal.style.display = 'block';
}

function closeVideoModal() {
    var modal = document.getElementById('videoModal');
    var video = document.getElementById('video');
    video.pause();
    video.src = "";
    modal.style.display = 'none';

}
</script>
<script>
function convertToUpperCase(element) {
    element.value = element.value.toUpperCase();
}
</script>



</body>

</html>