<?php 
    session_start();
    include "incs/db.php";
    if ($_SESSION['admin_logged_in'] !== true){
        
        $_SESSION['Admin_area'] = "You have Not Access";
        header("location:../index.php");
        die(); 
    }



?>