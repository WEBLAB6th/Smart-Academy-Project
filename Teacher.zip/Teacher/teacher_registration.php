<?php include "incs/auth.php" ?>
<?php include "incs/header.php" ?>
<?php include "incs/sidebar.php" ?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Teacher Registration</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active">Teacher Registration</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Teacher Registration</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            <?php 
                if (isset($_SESSION['teacher_error'])){ ?>
            <div class=" alert alert-danger alert-dismissible">
                <?php echo $_SESSION['teacher_error'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
            </div>
            <?php unset($_SESSION['teacher_error']);  }
            
            ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div>
                            <form action="teacher_registration_act.php" method="POST" enctype="multipart/form-data"
                                id="teacher_form">

                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="fname" class=" form-label">First Name</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" name="fname" id="fname" placeholder="Enter your First Name"
                                            class=" form-control">
                                    </div>

                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="lname" class=" form-label">Last Name</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" name="lname" id="lname" placeholder="Enter your Last Name"
                                            class=" form-control">
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="father_name" class=" form-label">Father Name</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" name="father_name" id="father_name"
                                            placeholder="Enter your Father Name" class=" form-control">
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="email" class=" form-label">Email</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="email" name="email" id="email" placeholder="Example@gmail.com"
                                            class=" form-control">
                                    </div>
                                </div>

                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="address" class=" form-label">Address</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" name="address" id="address" placeholder="Enter Your address"
                                            class=" form-control">
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="experience" class=" form-label">Experience</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" name="experience" id="experience" class=" form-control"
                                            placeholder="Enter Your experience">
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="description" class=" form-label">Description</label>
                                    </div>
                                    <div class="col-md-9">
                                        <textarea name="description" id="description" class=" form-control"
                                            placeholder="About your self" rows="10"></textarea>
                                    </div>
                                </div>

                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="image" class="form-label">Teacher Image</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="file" name="image" id="image" class=" form-control">

                                        <?php if (isset($_SESSION['teacher_image_extension_error'])){ ?>
                                        <small class=" d-block mt-1 alert alert-danger alert-dismissible">
                                            <?php echo $_SESSION['teacher_image_extension_error'] ?>
                                            <button type="button" class="close" data-dismiss="alert"
                                                aria-hidden="true">X</button>
                                        </small>
                                        <?php unset($_SESSION['teacher_image_extension_error']); } ?>
                                        <?php if (isset($_SESSION['teacher_image_uploads_error'])){ ?>
                                        <small class=" d-block mt-1 alert alert-danger alert-dismissible">
                                            <?php echo $_SESSION['teacher_image_uploads_error'] ?>
                                            <button type="button" class="close" data-dismiss="alert"
                                                aria-hidden="true">X</button>
                                        </small>
                                        <?php unset($_SESSION['teacher_image_uploads_error']); } ?>
                                    </div>
                                </div>

                                <div class="row mt-3">
                                    <div class="col-md-3">
                                        <label for="cv" class="form-label">CV</label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="file" name="cv" id="cv" class=" form-control">
                                        
                                        <?php if (isset($_SESSION['teacher_cv_extension_error'])){ ?>
                                        <small class=" d-block mt-1 alert alert-danger alert-dismissible">
                                            <?php echo $_SESSION['teacher_cv_extension_error'] ?>
                                            <button type="button" class="close" data-dismiss="alert"
                                                aria-hidden="true">X</button>
                                        </small>
                                        <?php unset($_SESSION['teacher_cv_extension_error']); } ?>
                                        <?php if (isset($_SESSION['teacher_cv_uploads_error'])){ ?>
                                        <small class=" d-block mt-1 alert alert-danger alert-dismissible">
                                            <?php echo $_SESSION['teacher_cv_uploads_error'] ?>
                                            <button type="button" class="close" data-dismiss="alert"
                                                aria-hidden="true">X</button>
                                        </small>
                                        <?php unset($_SESSION['teacher_cv_uploads_error']); } ?>
                                    </div>
                                </div>
                                <div class=" float-right mt-3">
                                    <input type="submit" value="Registration" name="teacher"
                                        class="btn btn-success btn-sm">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>



<?php include "incs/footer.php" ?>