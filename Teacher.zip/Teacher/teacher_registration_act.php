<?php 
    session_start();
    include "incs/db.php";

    if (isset($_POST['teacher'])){
        
        $fname =  $_POST['fname'];
        $lname =  $_POST['lname'];
        $father_name = $_POST['father_name'];
        $email =  $_POST['email'];
        $address = $_POST ['address'];
        $experience =  $_POST['experience'];
        $description =  $_POST['description'];
        $image_time = "";
        $cv_time = "";

        if ($_FILES['image']['size'] > 0){

            $image = $_FILES['image']['name'];
            $allow = array('jpg', 'jpeg','png','gif','bmp','tif','tiff','ico');
            $path = pathinfo($image,PATHINFO_EXTENSION);
            $image_time = time().'.'.$path;

            if(!in_array($path,$allow)){

                $_SESSION['teacher_image_extension_error'] = "This file is not supported";
                header("location: teacher_registration.php");
                die();
            }

            if (!move_uploaded_file($_FILES['image']['tmp_name'],'uploads/'.$image_time)){

                $_SESSION['teacher_image_uploads_error'] = "Somethings Wont Wrong";
                header("location:teacher_registration.php");
                die();
            }

        }

        if ($_FILES['cv']['size'] > 0){

            $cv = $_FILES['cv']['name'];
            $allow_cv = array('pdf','doc','PPTX');
            $path_cv = pathinfo($cv,PATHINFO_EXTENSION);
            $cv_time = time().'.'.$path_cv;

            if(!in_array($path_cv,$allow_cv)){

                $_SESSION['teacher_cv_extension_error'] = "This file is not supported";
                header("location: teacher_registration.php");
                die();
            }

            if (!move_uploaded_file($_FILES['cv']['tmp_name'],'uploads/'.$cv_time)){

                $_SESSION['teacher_cv_uploads_error'] = "Somethings Wont Wrong";
                header("location:teacher_registration.php");
                die();
            }

        }




        $sql = "INSERT INTO teachers (fname,lname,father_name,email,address,experience,description,image,cv) VALUES (?,?,?,?,?,?,?,?,?)";
        $result = $con -> prepare($sql);
        $result -> execute([$fname,$lname,$father_name,$email,$address,$experience,$description,$image_time,$cv_time]);

      

        if ($result){
            $_SESSION['teacher_success'] = "Successfully Submitted";
            header("Location: teacher_list.php");
            die();
        }else{
            $_SESSION['teacher_error'] = "Something Wont Wrong";
            header("Location: teacher_registration.php");
            die();
        }
    }

    




?>