<?php 
    session_start();
    include "incs/db.php";

    $encode = $_GET['id'];

    $id = base64_decode($encode);

    $sql = "DELETE FROM teachers WHERE id=?";
    $result = $con -> prepare($sql);
    $result -> execute([$id]);

    if ($result){

        $_SESSION['teacher_delete_success'] ="Deleted SuccessFully";
        header("Location: teacher_list.php");
        die();
    }else{
        $_SESSION['teacher_delete_error'] ="Something Went Wrong";
        header("Location: teacher_list.php");
        die();
    }






?>