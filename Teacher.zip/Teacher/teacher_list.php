<?php include "incs/auth.php" ?>

<?php include "incs/header.php" ?>
<?php include "incs/sidebar.php" ?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Teacher List</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active">Teacher List</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Teacher List</h3>
                <div class="card-tools">
                </div>
            </div>

            <?php 
                if (isset($_SESSION['teacher_delete_success'])){ ?>
            <div class=" alert alert-success alert-dismissible">
                <?php echo $_SESSION['teacher_delete_success'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
            </div>
            <?php unset($_SESSION['teacher_delete_success']);  }
            
            ?>

            <?php 
                if (isset($_SESSION['teacher_success'])){ ?>
            <div class=" alert alert-success alert-dismissible">
                <?php echo $_SESSION['teacher_success'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
            </div>
            <?php unset($_SESSION['teacher_success']);  }
            
            ?>

            <?php 
                if (isset($_SESSION['teacher_update_success'])){ ?>
            <div class=" alert alert-success alert-dismissible">
                <?php echo $_SESSION['teacher_update_success'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
            </div>
            <?php unset($_SESSION['teacher_update_success']);  }
            
            ?>

            <?php 
                if (isset($_SESSION['teacher_delete_error'])){ ?>
            <div class=" alert alert-danger alert-dismissible">
                <?php echo $_SESSION['teacher_delete_error'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
            </div>
            <?php unset($_SESSION['teacher_delete_error']);  }
            
            ?>



            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class=" table-responsive mb-5">
                            <table class="table table-bordered ">
                                <thead>
                                    <tr>
                                        <th>
                                            #
                                        </th>
                                        <th>
                                            First Name
                                        </th>
                                        <th>
                                            Last Name
                                        </th>
                                        <th>
                                            Father Name
                                        </th>
                                        <th>
                                            Email
                                        </th>
                                        <th>
                                            Address
                                        </th>
                                        <th>
                                            Experience
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                        <th>
                                            Teacher Image
                                        </th>
                                        <th>
                                            Cv
                                        </th>
                                        <th>
                                            Action
                                        </th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                $sn=1;
                                $sql = "SELECT * FROM teachers";
                                $result = $con -> prepare($sql);
                                $result -> execute();
                                foreach ($result as $row){ ?>
                                    <tr>
                                        <td><?php echo $sn++ ?></td>
                                        <td>
                                            <?php echo $row['fname'] ?></td>
                                        <td>
                                            <?php echo $row['lname'] ?></td>
                                        <td>
                                            <?php echo $row['father_name'] ?></td>
                                        <td>
                                            <?php echo $row['email'] ?></td>
                                        <td>
                                            <?php echo $row['address'] ?></td>
                                        <td><?php echo $row['experience'] ?></td>
                                        <td style="width: 300px; overflow: hidden;">
                                            <p class="description" style="overflow: hidden; max-height: 50px;">
                                                <?php echo $row['description'] ?>
                                            </p>
                                            <button class="btn btn-success btn-sm"
                                                onclick="toggleDescription(this)">Read
                                                More</button>
                                        </td>
                                        <td>
                                            <a href="#" onclick="openimageModal('<?php echo $row['image']; ?>')"><img
                                                    src="uploads/<?php echo $row['image'] ?>" alt="" width="100"></a>
                                            <div id="imageModal" class="modal">
                                                <div class="modal-content">
                                                    <img id="image" src="uploads/<?php echo $row['image'] ?>"
                                                        alt="image">
                                                    <span class="close" onclick="closeimageModal()">&times;</span>
                                                </div>
                                            </div>

                                        </td>
                                        <td style="width: 455px;">
                                            <a href="./uploads/<?php echo $row['cv'] ?>" target="_blank">View Cv</a>/ <a href="./uploads/<?php echo $row['cv'] ?>" download="download">Download</a>
                                        </td>


                                        
                                        <td style="width: 170px;">
                                            <?php $id = $row['id'];
                                            $encodeId = base64_encode($id);  ?>
                                            <a href="teacher_update.php?id=<?php echo urlencode($encodeId) ?>"
                                                class="btn btn-success btn-sm mb-1"
                                                onclick="return confirm('Are you went update this record')">Update</a>
                                            <a href="teacher_delete.php?id=<?php echo urlencode($encodeId) ?>"
                                                class="btn btn-danger btn-sm"
                                                onclick="return confirm('Are you Went to Delete this record')">Delete</a>
                                        </td>
                                    </tr>
                                    <?php }  ?>

                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>




            </div>
        </div>
    </section>
</div>



<?php include "incs/footer.php" ?>