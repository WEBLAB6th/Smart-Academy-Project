<?php 
    session_start();

    include "inc/db.php";

    if(isset($_POST['apply'])){
        
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $father_name = $_POST['father_name'];
        $email = $_POST['email'];
        $pnumber = $_POST['pnumber'];
        $address = $_POST['address'];
        $qualification = $_POST['qualification'];
        $course_id = $_POST['course_id'];
        $fee = $_POST['fee'];
        $image_time  = "";


        if ($_FILES['r_id']['size'] > 0){

            $image = $_FILES['r_id']['name'];
            $allow = array('jpg', 'jpeg','png','gif','bmp','tif','tiff','ico');
            $path = pathinfo($image,PATHINFO_EXTENSION);
            $image_time = time().'.'.$path;

            if(!in_array($path,$allow)){

                $_SESSION['apply_extension_error'] = "This file is not supported";
                header("location: services_details.php");
                die();
            }

            if (!move_uploaded_file($_FILES['r_id']['tmp_name'],'admin/uploads/'.$image_time)){

                $_SESSION['apply_uploads_error'] = "Somethings Wont Wrong";
                header("location: services_details.php");
                die();
            }

        }


        $sql = "INSERT INTO apply_form_students (fname,lname,father_name,email,pnumber,address,qualification,course_id,fee,r_id) VALUES (?,?,?,?,?,?,?,?,?,?)";
        $result = $con -> prepare($sql);
        $result -> execute([$fname,$lname,$father_name,$email,$pnumber,$address,$qualification,$course_id,$fee,$image_time]);

        if ($result){

            $_SESSION['apply_successfully'] = "Submitted";
            header("location:index.php");
            die();
        }else{
            $_SESSION['apply_error'] = "Something Wont Wrong";
            header("location: services_details");
            die();
        }
        
    }









?>