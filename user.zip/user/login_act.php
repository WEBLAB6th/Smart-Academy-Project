<?php 
    session_start();
    include "inc/db.php";

    if (isset($_POST['admin'])){

        $email = $_POST['email'];
        $password = $_POST['password'];

        
        $sql = "SELECT * FROM user WHERE email=? AND password=?";
        $result = $con -> prepare($sql);
        $result -> execute([$email,$password]);

        if ($result -> rowCount() > 0){

            
            $row = $result -> fetch(PDO::FETCH_ASSOC);
            $_SESSION['login_success'] = "Welcome To Admin Area";
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_logged_in'] = true;
            header("Location: admin/dashboard.php");

        }else{

            $_SESSION['login_error'] = "Login failed invalid credentials";
            header("Location: index.php");
            die();

        }

    }









?>