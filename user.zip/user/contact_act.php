<?php 
    session_start();
    include "inc/db.php";

    if (isset($_POST['contact'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $pnumber = $_POST['pnumber'];
        $msg = $_POST['msg'];

        
        $sql = "INSERT INTO contact (name,email,pnumber,msg) VALUES (?,?,?,?)";
        $result = $con-> prepare($sql);
        $result -> execute([$name,$email,$pnumber,$msg]);

   
        if($result){
            
            $_SESSION['success_contact'] = "Thank you for Contact";
            header("location: contact.php");
            die();
        }else{
            $_SESSION['success_error'] = "Something Wont Wrong";
            header("location: contact.php");
            die();
        }


    }






?>