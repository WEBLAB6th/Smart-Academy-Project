<?php include "inc/header.php" ?>
<div class="row">
    <div class="col-md-12 text-center align-items-center bg-cover" id="blog-post" style=" height: 300px;">
        <div style="position: relative; top: 50%; transform: translateY(-50%); text-align: center;" data-aos="zoom-in"
            data-aos-duration="3000">
            <h1 class="text-white" data-aos="fade-down" data-aos-duration="3000">
                Gallery
            </h1>
            <div class="container my-3 ">
                <div class="row ">
                    <div class="col-12 text-center " data-aos="fade-up" data-aos-duration="3000">
                        <a href="#" class="text-white"> Home &nbsp; &#187; &nbsp;</a>
                        <a href="#" class="text-white">Gallery </a>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<main id="main" class="portfolio">
    <div class="row mt-5 " data-aos="fade-up">
        <div class="col-lg-12 d-flex justify-content-center">

            <ul id="portfolio-flters">
                <li data-filter="*" class="filter-active">All</li>
            </ul>

        </div>
    </div>

    <div class="container">
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">
            <?php 
                $sql = "SELECT DISTINCT g.course_id, c.course_name, g.images 
                FROM gallery g
                JOIN courses c ON g.course_id = c.id";
                $result = $con -> prepare($sql);
                $result -> execute();
                $result_fetch_data = $result -> fetchALL(PDO::FETCH_ASSOC);
                foreach($result_fetch_data AS $row){ 
                    $id = $row['course_id'];
                    $encodeId = base64_encode($id);

                    $courseSql = "SELECT * FROM courses WHERE id = ?";
                    $courseResult = $con->prepare($courseSql);
                    $courseResult->execute([$id]);
                    $courseData = $courseResult->fetch(PDO::FETCH_ASSOC);
                    
                    ?>

            <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                <div class="portfolio-wrap">
                    <?php 
                        $images = explode(',',$row['images']); ?>
                    <img src="admin/uploads/<?php echo $images[0] ?>" class="img-fluid" alt="image">
                    <!--  -->
                    <div class="portfolio-links">
                        

                        <a href="gallery_details.php?id=<?php echo $encodeId ?>" title="More Details"><?php echo $courseData['course_name'] ?></i></a>
                    </div>
                </div>
            </div>
            <?php   } ?>
        </div>
    </div>
</main>


















<?php include "inc/footer.php" ?>