<?php include "inc/header.php" ?>

<div class="row">
    <div class="col-md-12">
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" data-bs-interval="2500">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                    aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                    aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <?php 
                $sql_slider = "SELECT * FROM slider";
                $sql_slider_result = $con -> prepare($sql_slider);
                $sql_slider_result -> execute();
                $sql_slider_result_fetch = $sql_slider_result -> fetchAll(PDO::FETCH_ASSOC);

                foreach($sql_slider_result_fetch AS $row_slider){ ?>

                <div class="carousel-item active">
                    <img src="admin/uploads/<?php echo $row_slider['image'] ?>" class="d-block w-100" alt="..."
                        style="height: 530px;">
                    <div
                        class="carousel-caption d-none d-md-block text-center position-absolute top-50 start-50 translate-middle">
                        <h5 class="text-light fw-bolder"><?php echo $row_slider['title'] ?></h5>
                        <p>
                            <?php echo $row_slider['description'] ?>
                        </p>
                    </div>
                </div>


                <?php } ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row mt-2 p-1 ">
        <div class="col-md-6 ">
            <div>
                <h2 class="shadow rounded p-1 d-inline-block ms-2" style="color:#5fcf80; border-bottom: 5px double red"
                    data-aos="fade-right" data-aos-duration="3000"> <i class="text">Welcome To Our Academy </i></h2>
            </div>
            <p class="lead text-start my-3" style="font-style: italic; color: #aaaaaa;" data-aos="fade-up"
                data-aos-duration="3000">"Welcome to our esteemed institution, the Smart Institute of Safety and Health,
                commonly known as the Safety-HSE Academy. As a premier educational hub, we take pride in our commitment
                to fostering a culture of safety, excellence, and innovation. At our academy, we prioritize the
                well-being of individuals and communities by providing cutting-edge training in Health, Safety, and
                Environment (HSE) practices.

                Our dedicated faculty comprises industry experts and experienced professionals who impart knowledge
                through state-of-the-art curriculum and hands-on training. Students at the Safety-HSE Academy benefit
                from a comprehensive learning environment that equips them with the skills and expertise needed to excel
                in the field of occupational health and safety.
                As a Smart Institute, we leverage technology to enhance the learning experience. Our modern facilities
                include advanced laboratories, simulation rooms, and e-learning platforms, providing students with a
                well-rounded educational journey. We are dedicated to fostering a supportive and inclusive learning
                environment, where students collaborate, innovate, and grow both personally and professionally.
                Join us at the Safety-HSE Academy, where we are shaping the future leaders of health, safety, and
                environmental practices. Here, education goes beyond the classroom – it's an immersive experience that
                prepares individuals to lead with competence and compassion in a rapidly evolving global landscape.
                Welcome to a journey of knowledge, safety, and professional excellence."

            </p>

        </div>
        <div class="col-md-6 text-center">
            <img src="images/h8-banner1.png" alt="" class=" img-fluid " style="width: 30rem;" data-aos="fade-down"
                data-aos-duration="3000">
        </div>
    </div>
</div>


<div class="row mt-2">
    <div class="col-md-12">
        <section id="counts" class="counts section-bg" data-aos="zoom-in" data-aos-duration="3000">
            <div class="container">

                <div class="row counters">
                    <?php 
                         $total_students = "SELECT count(*) AS total_students FROM apply_form_students";
                         $total_students_result = $con -> prepare($total_students);
                         $total_students_result-> execute();
                         $students = $total_students_result -> fetch(PDO::FETCH_ASSOC);
                         $total_students_result_total = $students['total_students'];
                    ?>
                    <div class="col-lg-3 col-6 text-center">
                        <span data-purecounter-start="0"
                            data-purecounter-end="<?php echo $total_students_result_total ?>"
                            data-purecounter-duration="3" class="purecounter"></span>
                        <h5>Students</h4>
                    </div>
                    <?php  
                        $total_courses = "SELECT count(*) AS total_course FROM courses";
                        $total_courses_result = $con-> prepare($total_courses);
                        $total_courses_result -> execute();
                        $total_courses = $total_courses_result -> fetch(PDO::FETCH_ASSOC);
                        $total_cour = $total_courses['total_course'];
                        
                        ?>
                    <div class="col-lg-3 col-6 text-center">
                        <span id="coursesCounter" data-purecounter-start="0"
                            data-purecounter-end="<?php echo $total_cour  ?>" data-purecounter-duration="3"
                            class="purecounter"></span>
                        <h5>Courses</h5>
                    </div>

                    <div class="col-lg-3 col-6 text-center">
                        <span data-purecounter-start="0" data-purecounter-end="42" data-purecounter-duration="3"
                            class="purecounter"></span>
                        <h5>Events</h5>
                    </div>

                    <div class="col-lg-3 col-6 text-center">
                        <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="3"
                            class="purecounter"></span>
                        <h5>Trainers</h5>
                    </div>

                </div>

            </div>
        </section>

    </div>

</div>
<div class="container mt-5">
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="text-center" data-aos="zoom-out" data-aos-duration="3000">
                <h2 class="text-center" style="color:#5fcf80; border-bottom: 5px double red; display:inline-block">
                    <i class="text"> Why Choose Us </i>
                </h2>
            </div>
            <section id="why-us" class="why-us">
                <div class="container">
                    <div class=" row">
                        <div class="col-lg-4 d-flex align-items-stretch" data-aos="fade-up" data-aos-duration="3000">
                            <div class="content">
                                <h3 class="text-white">Why Choose Smart?</h3>
                                <p>
                                    Choose Smart for a transformative learning experience. Our commitment to
                                    cutting-edge education, industry relevance, and a supportive community ensures
                                    you're equipped for success in today's dynamic world. Elevate your future with Smart
                                    Institute.
                                </p>

                            </div>
                        </div>
                        <div class="col-lg-8 d-flex align-items-stretch">
                            <div class="icon-boxes d-flex flex-column justify-content-center">
                                <div class="row">
                                    <div class="col-xl-4 d-flex align-items-stretch" data-aos="fade-down"
                                        data-aos-duration="3000">
                                        <div class="icon-box mt-4 mt-xl-0">
                                            <i class="fas fa-laptop-code" aria-hidden="true"></i>

                                            <h4>Online Courses</h4>
                                            <p>Empower your learning journey with our diverse and accessible online
                                                courses, designed for flexible education anytime, anywhere</p>
                                        </div>
                                    </div>
                                    <div class="col-xl-4 d-flex align-items-stretch">
                                        <div class="icon-box mt-4 mt-xl-0" data-aos="fade-up" data-aos-duration="3000">
                                            <i class="fas fa-trophy"></i>
                                            <h4>Earn A Certificates</h4>
                                            <p>Unlock opportunities and enhance your skills with our certificate
                                                programs, recognizing your achievements and expertise</p>
                                        </div>
                                    </div>
                                    <div class="col-xl-4 d-flex align-items-stretch" data-aos="fade-down"
                                        data-aos-duration="3000">
                                        <div class="icon-box mt-4 mt-xl-0">
                                            <i class="fas fa-graduation-cap"></i>
                                            <h4>Learn with Expert</h4>
                                            <p>Accelerate your learning journey with our courses led by industry
                                                experts, gaining insights and skills for success.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
        </div>

    </div>

</div>

</div>
</div>
<div class="row mt-5" data-aos="fade-left" data-aos-duration="3000">
    <div class="col-md-12">
        <div class="text-center mb-4">
            <h2 style="color:#5fcf80;border-bottom: 5px double red; display:inline-block"><i class="text">Our
                    Courses</i></h2>
        </div>
        <div class="owl-carousel owl-theme">
            <?php 
                $total_courses_2 = "SELECT *  FROM courses WHERE status =1";
                $total_courses_result_2 = $con-> prepare($total_courses_2);
                $total_courses_result_2 -> execute();
                $total_courses_2 = $total_courses_result_2 -> fetchAll(PDO::FETCH_ASSOC);
                foreach($total_courses_2 AS $cour_row){ ?>
            <div class="item">
                <div class="card" style="width:25rem; height:30rem" >
                    <img src="admin/uploads/<?php echo$cour_row['image']  ?>" class="card-img-top" alt="..."
                       style="width: 398px; height:250px;">
                    <div class="card-body" >
                        <div>
                            <h5 class="card-title d-inline-block"><?php echo$cour_row['course_name']  ?> </h5>
                            <h6 class="d-inline-block float-end">fee: <?php echo$cour_row['fee']  ?>PKR</h6>
                        </div>

                        <p class="card-text"><?php 
                            
                            $courseDescription = $cour_row['course_description'];
                            $words = str_word_count($courseDescription, 1);
                     
                            if (count($words) > 25) {
                                $limitedWords = implode(' ', array_slice($words, 0, 25));
                                echo $limitedWords . '...';
                            } else {
                                echo $courseDescription;
                            }
                         ?></p>
                        <div class="text-center">
                            <?php
                                $id1 = $cour_row['id'];
                                $encodeId1 = base64_encode($id1);
                            ?>
                            <a href="services_details.php?id=<?php echo  urlencode($encodeId1) ?>"
                                class="btn btn-outline-success btn-sm">Read More</a>
                        </div>

                    </div>
                </div>
            </div>
            <?php  } ?>
        </div>

    </div>
</div>
<div class="row mt-5">
    <div class="col-md-12">
        <div class="text-center">
            <h2 style="color:#5fcf80;border-bottom: 5px double red; display:inline-block"><i class="text">Our
                    Trainers</i></h2>
        </div>
        <!-- ======= Trainers Section ======= -->
        <section id="trainers" class="trainers">
            <div class="container" data-aos="fade-up">

                <div class="row">
                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up"
                        data-aos-duration="3000">
                        <div class="member">
                            <img src="images/trainer-1.jpg" class="img-fluid" alt="">
                            <div class="member-content">
                                <h4>Walter White</h4>
                                <span>Web Development</span>
                                <p>
                                    Magni qui quod omnis unde et eos fuga et exercitationem. Odio veritatis
                                    perspiciatis quaerat qui aut aut aut
                                </p>
                                <div class="social">
                                    <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                                    <a href=""><i class="fa-brands fa-twitter"></i></a>
                                    <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-down"
                        data-aos-duration="3000">
                        <div class="member">
                            <img src="images/trainer-2.jpg" class="img-fluid" alt="">
                            <div class="member-content">
                                <h4>Sarah Jhinson</h4>
                                <span>Marketing</span>
                                <p>
                                    Repellat fugiat adipisci nemo illum nesciunt voluptas repellendus. In architecto
                                    rerum rerum temporibus
                                </p>
                                <div class="social">
                                    <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                                    <a href=""><i class="fa-brands fa-twitter"></i></a>
                                    <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up"
                        data-aos-duration="3000">
                        <div class="member">
                            <img src="images/trainer-3.jpg" class="img-fluid" alt="">
                            <div class="member-content">
                                <h4>William Anderson</h4>
                                <span>Content</span>
                                <p>
                                    Voluptas necessitatibus occaecati quia. Earum totam consequuntur qui porro et
                                    laborum toro des clara
                                </p>
                                <div class="social">
                                    <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                                    <a href=""><i class="fa-brands fa-instagram"></i></a>
                                    <a href=""><i class="fa-brands fa-twitter"></i></a>
                                    <a href=""><i class="fa-brands fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section><!-- End Trainers Section -->
    </div>
</div>

<div class="row">
    <div class="col-md-12">

        <section id="testimonials" class="bg-cover" data-aos="fade-down" data-aos-duration="3000">
            <div class="row ">
                <div class="col-12 intro text-center ">
                    <h6 class="text-uppercase text" data-aos="fade-up" data-aos-duration="3000">Our Reviews</h6>
                    <h1 class="text-white" data-aos="fade-up" data-aos-duration="3000">What Clients say About
                        us?
                    </h1>

                </div>
            </div>

            <div class="owl-carousel owl-theme" id="testimonial-slider">
                <?php 
                     $sql_review = "SELECT * FROM reviews";
                     $result_review = $con -> prepare($sql_review);
                     $result_review -> execute();
                     foreach ($result_review as $key => $row_review){ ?>
                
                <div class="item">
                    <div class="testimonial">
                        <img src="images/logo.png" alt="">
                        <h4><?php echo $row_review['name'] ?></h4>
                        <p><?php echo $row_review['review'] ?></p>
                    </div>
                </div>
                <?php } ?>
            </div>
        </section>
    </div>
</div>

<div class="row mt-5 mb-4 justify-content-center">
    <div class="col-md-7">
        <div class="text-center mb-4">
            <h2 style="color:#5fcf80;border-bottom: 5px double red; display:inline-block"><i class="text">Your Review
        </div>
        <div class=" shadow-lg p-5 rounded">
            <form action="" method="post">
                <div class="row mt-3" data-aos="fade-right" data-aos-duration="3000">
                    <div class="col-md-2">
                        <label for="fname" class=" form-label"> Name</label>
                    </div>
                    <div class="col-md-10">
                        <input type="text" name="fname" id="fname" class=" form-control" placeholder="Enter Name">
                    </div>
                </div>
                <div class="row mt-3 " data-aos="fade-left" data-aos-duration="3000">
                    <div class="col-md-2">
                        <label for="email" class=" form-label"> E-mail</label>
                    </div>
                    <div class="col-md-10">
                        <input type="email" name="email" id="email" class=" form-control"
                            placeholder="Example@gmail.com">
                    </div>
                </div>
                <div class="row mt-3" data-aos="fade-right" data-aos-duration="3000">
                    <div class="col-md-2">
                        <label for="review" class=" form-label">Review</label>
                    </div>
                    <div class="col-md-10">
                        <textarea name="review" id="review" rows="10" class=" form-control"
                            placeholder="Enter your Review"></textarea>
                    </div>
                </div>
                <div class="mt-4 text-end" data-aos="fade-left" data-aos-duration="3000">
                    <input type="submit" value="Send" name="review" class="btn btn-outline-success btn-sm pe-5 ps-5">
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "inc/footer.php" ?>