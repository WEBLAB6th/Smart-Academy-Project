<?php 
    include "inc/header.php";
 
    
?>
<div class="row">
    <div class="col-md-12 text-center align-items-center bg-cover" id="blog-post" style=" height: 300px;">
        <div style="position: relative; top: 50%; transform: translateY(-50%); text-align: center;" data-aos="zoom-in"
            data-aos-duration="3000">
            <h1 class="text-white" data-aos="fade-down" data-aos-duration="3000">
                Student Details
            </h1>
            <div class="container my-3 ">
                <div class="row ">
                    <div class="col-12 text-center " data-aos="fade-up" data-aos-duration="3000">
                        <a href="#" class="text-white"> Home &nbsp; &#187; &nbsp;</a>
                        <a href="#" class="text-white">Student Details</a>

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>


<div class="row mt-5">
    <div class="col-md-12">
        <?php 
            $id = $_GET['id'];
            $sql = "SELECT c.*,a.*,co.course_name AS course FROM apply_form_students AS a INNER JOIN certificate_details AS c ON c.student_id=a.id INNER JOIN courses as co ON a.course_id = co.id WHERE c.id=?;";
            $result = $con -> prepare($sql);
            $result -> execute([$id]);
            $data = $result->fetch(PDO::FETCH_ASSOC);

          
            

            
        ?>
        <div class=" text-center " data-aos="fade-down" data-aos-duration="3000">
            <img style="width:1100px; height:600px" src="./admin/uploads/<?php echo $data['certificate'] ?>" alt=""
                class="img-fluid shadow-lg p-2">
        </div>
        <div class="portfolio-info mt-5 text-center" >
            <h3 class="mb-4" style="text-decoration: underline;" data-aos="fade-left" data-aos-duration="3000">Student information</h3>
            <ul class="" style="list-style: none;" data-aos="fade-right" data-aos-duration="3000">
                <li><strong>Full Name</strong>: <?php echo $data['fname'].' '.$data['lname'] ?></li>
                <li><strong>Father Name</strong>: <?php echo $data['father_name'] ?></li>
                <li><strong>Address</strong>:<?php echo $data['address'] ?></li>
                <li><strong>Email</strong>:<?php echo $data['email'] ?></li>
                <li><strong>Course</strong>:<?php echo $data['course'] ?></li>
                <li><strong>Issue Date</strong>:<?php echo $data['date'] ?> </li>
            </ul>
        </div>
    </div>

</div>


<?php include "inc/footer.php" ?>