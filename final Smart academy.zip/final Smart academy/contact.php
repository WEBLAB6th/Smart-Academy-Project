<?php include "inc/header.php" ?>


<div class="row">
    <div class="col-md-12 text-center align-items-center bg-cover" id="blog-post" style=" height: 300px;">
        <div style="position: relative; top: 50%; transform: translateY(-50%); text-align: center;" data-aos="zoom-in"
            data-aos-duration="3000">
            <h1 class="text-white" data-aos="fade-down" data-aos-duration="3000">
                CONTACT US
            </h1>
            <div class="container my-3 ">
                <div class="row ">
                    <div class="col-12 text-center " data-aos="fade-up" data-aos-duration="3000">
                        <a href="#" class="text-white"> Home &nbsp; &#187; &nbsp;</a>
                        <a href="#" class="text-white">Gallery &nbsp; &#187; &nbsp; </a>
                        <a href="#" class="text-white">Courses &nbsp; &#187; &nbsp; </a>
                        <a href="#" class="text-white">Contact Us</a>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<div class="container">
    <div class="row mt-3  ">
        <div class="col-md-6  border border-3 border-bottom-0 border-start-0 border-top-0">
            <div class="p-5 rounded shadow-sm h-100" style="background: #f5f6f7;">
                <h3 class="text-center mb-5
            " data-aos="zoom-in" data-aos-duration="3000">Contact Us</h3>
                <form action="contact_act.php" method="POST">
                    <div class="input-group mb-3" data-aos="fade-out" data-aos-duration="3000">
                        <span class="input-group-text" id="basic-addon1"><i class="fa-regular fa-user"></i></span>
                        <input type="text" class="form-control" placeholder="Username" aria-label="Username"
                            aria-describedby="basic-addon1" name="name">
                    </div>

                    <div class="input-group mb-3" data-aos="fade-down" data-aos-duration="3000">
                        <span class="input-group-text" id="basic-addon2"><i class="fa-solid fa-envelope"></i></span>
                        <input type="text" class="form-control" placeholder="example@gmail.com"
                            aria-label="Recipient's username" aria-describedby="basic-addon2" name="email">

                    </div>
                    <div class="input-group mb-3" data-aos="fade-up" data-aos-duration="3000">
                        <span class="input-group-text"><i class="fa-solid fa-phone"></i></span>
                        <input type="number" class="form-control" aria-label="" placeholder="Enter your phone number" name="pnumber">

                    </div>

                    <div class="input-group" data-aos="fade-down" data-aos-duration="3000">
                        <span class="input-group-text"><i class="fa-solid fa-message"></i></span>
                        <textarea class="form-control" aria-label="With textarea" rows="5"
                            placeholder="Enter a message" name="msg"></textarea>
                    </div>
                    <div class="text-end mt-3" data-aos="fade-left" data-aos-duration="3000">
                        <input type="submit" value="Send" name="contact"
                            class="btn btn-outline-success btn-sm ps-3 pe-3">
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-4 m-auto p-5" style="background: #f5f6f7; font-size:small;">
            <div>
                <h2 class="mt-2 text-uppercase" style="font-size: 18px; font-family: initial" data-aos="zoom-in"
                    data-aos-duration="3000">
                    Let's get in touch</h2>
                <h5 style="font-size: 14px; font-family: initial" data-aos="zoom-in" data-aos-duration="3000">We're open
                    for
                    any suggestion or just to have a chat</h5>
                <div>
                    <div class="mt-5 d-flex" data-aos="fade-right" data-aos-duration="3000">
                        <div>
                            <span><i class="fa-solid fa-location-dot" style="font-size:18px;"></i></span>
                        </div>
                        <div>
                            <h5 class=" ms-3 text-muted" style="font-size: 18px; font-family: initial"> Address: 9VVX+5VX, Gul shopping mall hathian chowk main bazar, Shergarh, Mardan, Khyber Pakhtunkhwa, Pakistan</h5>
                        </div>
                    </div>
                    <div class="mt-5 d-flex" data-aos="fade-left" data-aos-duration="3000">
                        <div>
                            <span><i class="fa-solid fa-phone" style="font-size:18px;"></i></span>
                        </div>
                        <div>
                            <h5 class="mt-1 ms-3 text-muted" style="font-size: 18px; font-family: initial">Phone: +92 303 8163603
                            </h5>
                        </div>
                    </div>

                    <div class="mt-5 d-flex" data-aos="fade-right" data-aos-duration="3000">
                        <div>
                            <span><i class="fa-regular fa-paper-plane " style="font-size:18px;"></i></span>
                        </div>
                        <div>
                            <h5 class="mt-1 ms-3 text-muted" style="font-size: 18px; font-family: initial">Email:
                                info@siitsafety.com
                            </h5>
                        </div>
                    </div>
                    <div class="mt-5 d-flex" data-aos="fade-left" data-aos-duration="3000">
                        <div>
                            <span><i class="fa-solid fa-earth-africa" style="font-size:18px;"></i></span>
                        </div>
                        <div>
                            <h5 class="ms-3 text-muted" style="font-size: 18px; font-family: initial">Website:
                                www.siitsafety.com</h5>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
    <div class="row mt-5">
        <div class="col-md-12" data-aos="fade-down" data-aos-duration="3000">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3292.3285986980754!2d71.89716647425398!3d34.39299289966368!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38d953e1b1577f5b%3A0xc0a9618471a8e02d!2sSmart%20Institute%20Of%20IT%20Shergarh!5e0!3m2!1sen!2s!4v1701630737222!5m2!1sen!2s"
                width="1300" height="500" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>

        </div>
    </div>
</div>











<?php include "inc/footer.php" ?>