    <div class="row mt-5 border border-bottom-0 border-start-0 border-end-0 border-5 p-3">
        <div class="container-fluid bg_dark">
            <div class="col-md-12 mt-3">
                <footer id="footer" data-aos="zoom-out" data-aos-duration="3000">
                    <div class="footer-top">
                        <div class="container">
                            <div class="row">

                                <div class="col-lg-3 col-md-6 footer-contact">
                                    <h4>Smart Academy</h4>
                                    <p>
                                    <strong>Address:</strong>
                                    9VVX+5VX, Gul shopping <br> mall hathian chowk <br> main bazar, Shergarh,<br> Mardan, Khyber Pakhtunkhwa, Pakistan <br>
                                        <br>
                                        <strong>Phone:</strong> +92 303 8163603<br>
                                        <strong>Email:</strong>info@siitsafety.com<br>
                                    </p>
                                </div>

                                <div class="col-lg-2 col-md-6 footer-links">
                                    <h4>Useful Links</h4>
                                    <ul>
                                        <li><i class="bx bx-chevron-right"></i> <a href="./index.php">Home</a></li>
                                        <li><i class="bx bx-chevron-right"></i> <a href="./about.php">About us</a></li>
                                        <li><i class="bx bx-chevron-right"></i> <a href="./contact.php">Contact Us</a></li>

                                        <li><i class="bx bx-chevron-right"></i> <a href="gallery.php">Gallery</a></li>
                                        
                                    </ul>
                                </div>

                                <div class="col-lg-3 col-md-6 footer-links">
                                    <h4>Our Services</h4>
                                    <ul>
                                        <li><i class="bx bx-chevron-right"></i> <a>Web Design</a></li>
                                        <li><i class="bx bx-chevron-right"></i> <a>Web Development</a></li>
                                        <li><i class="bx bx-chevron-right"></i> <a>Safety</a></li>
                                        <li><i class="bx bx-chevron-right"></i> <a>Marketing</a></li>
                                        <li><i class="bx bx-chevron-right"></i> <a>Graphic Design</a></li>
                                    </ul>
                                </div>

                                <div class="col-lg-4 col-md-6 footer-newsletter">
                                    <h4>Join Our Newsletter</h4>
                                    <p>Stay informed and connected! Join our newsletter for exclusive updates, valuable insights, and exciting opportunities delivered right to your inbox.</p>

                                </div>

                            </div>
                        </div>
                    </div>


                </footer>
            </div>
        </div>
    </div>




    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
    <script src="./assets/js/jquery.min.js"></script>
    <script src="./assets/js/jquery.validate.min.js"></script>
    <script src="./assets/purecounter/purecounter_vanilla.js"></script>
    <script src="./assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/aos-master/dist/aos.js"></script>
    <script src="https://kit.fontawesome.com/a0add6ad96.js" crossorigin="anonymous"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script> -->
    <script src="assets/owl/owl.carousel.min.js"></script>
    <!-- Popper.js CDN -->





    <script>
AOS.init();
    </script>

<script>
$(document).ready(function() {
    $('#showPassword').change(function() {
        var passwordField = $('#password');
        var isChecked = $(this).is(':checked');
        passwordField.attr('type', isChecked ? 'text' : 'password');
    });
});
</script>


    <script>
document.addEventListener('DOMContentLoaded', function() {
    var coursesCounter = document.getElementById('coursesCounter');

    new PureCounter(coursesCounter, {

    });
});
    </script>

    <script>
$(document).ready(function() {
    $('#testimonial-slider').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    })
});
    </script>

    <script>
$(document).ready(function() {
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        autoplay: true,
        dots: false,
        autoplayTimeout: 3000,
        autoWidth: true,
        autoHeight: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 3
            },
            1000: {
                items: 3
            }
        }
    })
});
    </script>

    </body>

    </html>