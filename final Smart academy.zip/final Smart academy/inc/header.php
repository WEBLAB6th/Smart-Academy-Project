<?php session_start();

include "inc/db.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Institute of it & Safety-HSE</title>
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/aos-master/dist/aos.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/owl/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/owl/owl.theme.default.min.css">


    <!--
    animation css
        <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/> -->
</head>

<body>
    <!-- login model code -->
    <div class="modal fade " id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Admin Area</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="login_act.php" method="post">
                        <div class="mb-3">
                            <label for="admin_email" class="form-label">Email address</label>
                            <input type="email" class="form-control" name="email" id="admin_email"
                                placeholder="name@example.com">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" id="password" name="password" class="form-control"
                                aria-describedby="passwordHelpInline" placeholder="**************">
                        </div>
                        <div class="mb-2">
                            <input type="checkbox" id="showPassword"> Show Password
                        </div>
                        <div class="modal-footer">
                            <a href="" class="me-auto ">Forgot Password</a>
                            <button type="submit" name="admin" class="btn btn-success ">Admin Area</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>



    <div class="container-fluid g-0 bg_dark">
        <div class="container">
            <div class="row justify-content-between d-flex ">
                <!-- social links -->
                <div class="col-md-12  p-2 d-none d-lg-block sticky-top">
                    <div class="social-links me-4 float-end">
                        <a href="https://www.facebook.com/help/668969529866328" data-aos="fade-right" data-aos-duration="3000"><i
                                class="fa-brands fa-facebook-f"></i></a>
                        <a href="https://www.instagram.com/" data-aos="fade-left" data-aos-duration="3000"><i
                                class="fa-brands fa-instagram"></i></a>
                        <a href="https://twitter.com/?lang=en" data-aos="fade-right" data-aos-duration="3000"><i
                                class="fa-brands fa-twitter"></i></a>
                        <a href="https://pk.linkedin.com/" data-aos="fade-left" data-aos-duration="3000"><i
                                class="fa-brands fa-linkedin-in"></i></a>

                    </div>
                    <div class=" d-inline-flex mt-1 text-white">
                        <p class="ms-3 " data-aos="fade-up" data-aos-duration="3000"><i
                                class="fa-solid fa-envelope"></i>
                            <span>info@siitsafety.com</span>
                        </p>
                        <p class="ms-3" data-aos="fade-down" data-aos-duration="3000"><i
                                class="fa-solid fa-phone"></i></i>
                            <span>+92 303 8163603</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- menu section -->
    <div class="container">
        <div class="row">
            <div class="col-md-12 ">
                <nav class="navbar navbar-expand-lg sticky-top">
                    <div class="container-fluid">
                        <a class="navbar-brand ms-3" data-aos="fade-right" data-aos-duration="3000"
                            href="index.php"><img src="images/logo.png" alt="" width="50"></a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 main_menu" data-aos="fade-left"
                                data-aos-duration="3000">
                                <li class="nav-item">
                                    <a class="nav-link " aria-current="page" href="index.php">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="gallery.php">Gallery</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        Courses
                                    </a>
                                    <ul class="dropdown-menu sub_menu">
                                        <?php 
                                            $courses = "SELECT * FROM courses WHERE status =1";
                                            $courses_result = $con -> prepare($courses);
                                            $courses_result -> execute();
                                            $courses_result_fetch = $courses_result -> fetchAll(PDO::FETCH_ASSOC);
                                            foreach ( $courses_result_fetch AS $course_row){ 
                                                $id = $course_row['id'];
                                                $encodeId = base64_encode($id);?>


                                                <li><a class="dropdown-item text-center" href="services_details.php?id=<?php echo  urlencode($encodeId) ?>"><?php echo  $course_row['course_name'] ?></a> </li>
                                            <?php }  ?>
                                       
                                        <!-- <li><a class="dropdown-item text-center" href="services_details.php">IOSH</a>
                                        </li>
                                        <li><a class="dropdown-item text-center" href="services_details.php">OSHA</a>
                                        </li> -->
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link " href="contact.php">Contact</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link " href="about.php">About</a>
                                </li>
                                <?php if (isset($_SESSION['admin_logged_in']) ==true){ ?>
                                <li class="nav-item ms-md-2">
                                    <a href="admin/dashboard.php"
                                        class="nav-link btn btn-sm  pe-4 ps-4 login">Dashboard</a>
                                </li>
                                <li class="nav-item ms-md-2">
                                    <a href="./logout.php" class="nav-link btn btn-sm  pe-4 ps-4 login">Logout</a>
                                </li>
                                <?php }else{ ?>
                                <li class="nav-item ms-md-2">
                                    <a type="button" class="nav-link btn btn-sm  pe-4 ps-4 login" data-bs-toggle="modal"
                                        data-bs-target="#exampleModal">Login</a>
                                </li>
                                <?php  } ?>


                            </ul>
                        </div>
                    </div>
                </nav>

            </div>
        </div>
        <div class="position-fixed me-4" style="z-index: 1; right:0;">
            <a class="" aria-label="Chat on WhatsApp" href="https://wa.me/923038163603"> <img width="60" alt="Chat on WhatsApp" src="images/square-whatsapp.svg" /><a />
        </div>
    </div>
   