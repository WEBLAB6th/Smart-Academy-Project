<?php include "inc/header.php" ?>
<?php 
    $encode = $_GET['id'];
    $id =base64_decode($encode);
    $courses = "SELECT * FROM courses WHERE status =1 AND id=?";
    $courses_result = $con -> prepare($courses);
    $courses_result -> execute([$id]);
    $courses_result_fetch = $courses_result -> fetch(PDO::FETCH_ASSOC);

?>
<div class="row">
    <div class="col-md-12 text-center align-items-center bg-cover" id="blog-post" style=" height: 300px;">
        <div style="position: relative; top: 50%; transform: translateY(-50%); text-align: center;" data-aos="zoom-in"
            data-aos-duration="3000">
            <h1 class="text-white" data-aos="fade-down" data-aos-duration="3000">
                <?php echo $courses_result_fetch['course_name'] ?>
            </h1>
            <div class="container my-3 ">
                <div class="row ">
                    <div class="col-12 text-center " data-aos="fade-up" data-aos-duration="3000">
                        <a href="#" class="text-white"> Home &nbsp; &#187; &nbsp;</a>
                        <a href="#" class="text-white">Gallery &nbsp; &#187; &nbsp; </a>
                        <a href="#" class="text-white">Courses &nbsp; &#187; &nbsp; </a>
                        <a href="#" class="text-white">OSHA</a>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<div class="container">
    <div class="row mt-3">
        <div class="col-md-12">
            <div class="section-title">
                <h2 class="text" data-aos="fade-down" data-aos-duration="3000"><?php echo $courses_result_fetch['course_name'] ?></h2>
                <p class="ms-3 me-3" data-aos="fade-up" data-aos-duration="3000"><?php echo $courses_result_fetch['course_description'] ?></p>
            </div>
        </div>
    </div>
</div>
<div class="border border-bottom-0 border-start-0 border-end-0 border-5 p-3"></div>
<div class="container">
    <div class="row  g-0 ms-3 ">
        <div class="col-md-6 mt-5">
            <div class="section-title">
                <h2 class="text-center text-success" data-aos="fade-down" data-aos-duration="3000"> <i> Admission From
                    </i>
                </h2>
            </div>
            <div>
                <form action="services_details_act.php" method="post" enctype="multipart/form-data"
                    data-aos="fade-right" data-aos-duration="3000">

                    <div class="row">
                        <div class="col-md-3">
                            <label for="fname" class=" form-label">First Name</label>
                        </div>
                        <div class="col-md-9">
                            <input type="text" name="fname" id="fname" placeholder="Enter your First Name"
                                class=" form-control">
                        </div>

                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="lname" class=" form-label">Last Name</label>
                        </div>
                        <div class="col-md-9">
                            <input type="text" name="lname" id="lname" placeholder="Enter your Last Name"
                                class=" form-control">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="father_name" class=" form-label">Father Name</label>
                        </div>
                        <div class="col-md-9">
                            <input type="text" name="father_name" id="father_name" placeholder="Enter your father Name"
                                class=" form-control">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="email" class=" form-label">Email</label>
                        </div>
                        <div class="col-md-9">
                            <input type="email" name="email" id="email" placeholder="Example@gmail.com"
                                class=" form-control">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="pnumber" class=" form-label">Phone Number</label>
                        </div>
                        <div class="col-md-9">
                            <input type="text" name="pnumber" id="pnumber" class=" form-control"
                                placeholder="Enter your phone number">
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="address" class=" form-label">Address</label>
                        </div>
                        <div class="col-md-9">
                            <input type="text" name="address" id="address" placeholder="Enter Your address"
                                class=" form-control">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="qualification" class="form-label">Qualification</label>
                        </div>
                        <div class="col-md-9">
                            <input type="text" name="qualification" id="qualification" class=" form-control"
                                placeholder="Enter Your Qualification">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="course_id" class=" form-label">Course</label>
                        </div>
                        <div class="col-md-9">
                            <input type="hidden" name="course_id" id="course_id" value="<?php echo $courses_result_fetch['id'] ?>">
                            <input type="text"  value="<?php echo $courses_result_fetch['course_name'] ?>" class=" form-control"
                                readonly>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="fee" class=" form-label">Fee</label>
                        </div>
                        <div class="col-md-9">
                            <input type="text" name="fee" id="fee" class=" form-control" placeholder="Enter Amount">
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-3">
                            <label for="r_id" class=" form-label">Receipt id</label>
                        </div>
                        <div class="col-md-9">
                            <input type="file" name="r_id" id="r_id" placeholder="Enter Your address"
                                class=" form-control">
                        </div>
                    </div>
                    <div class="text-end mt-4 ">
                        <input type="submit" value="Apply " class="btn btn-outline-success pt-2 pb-2 w-75" name="apply">
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-6 mt-5">
            <div class="section-title" data-aos="fade-left" data-aos-duration="3000">
                <h2 class="text-center text-success"> <i> Payment Methods</i></h2>
            </div>
            <div class="ms-4" data-aos="fade-left" data-aos-duration="3000">
                <p>To facilitate a smooth admission process, please find below the available payment methods for your
                    convenience:
                    Kindly ensure the accuracy of the provided details to ensure a secure and seamless payment
                    experience. If you have any questions or require assistance, feel free to reach out to our admission
                    office.

                    We appreciate your cooperation, and we look forward to receiving your payment.</p>
            </div>
            <div class="ms-4" data-aos="fade-up" data-aos-duration="3000">
                <ul>
                    <li>
                        <h5>Method:</h5>
                    </li>
                    <li>
                        <h5>Account Name:</h5>
                    </li>
                    <li>
                        <h5>Account NO:</h5>
                    </li>
                    <hr>
                    <li>
                        <h5>Method:</h5>
                    </li>
                    <li>
                        <h5>Account Name:</h5>
                    </li>
                    <li>
                        <h5>Account NO:</h5>
                    </li>
                    <hr>
                    <li>
                        <h5>Method:</h5>
                    </li>
                    <li>
                        <h5>Account Name:</h5>
                    </li>
                    <li>
                        <h5>Account NO:</h5>
                    </li>


                </ul>
            </div>
        </div>

    </div>
</div>

<?php include "inc/footer.php" ?>