<?php include "inc/header.php" ?>
<div class="row">
    <div class="col-md-12 text-center align-items-center bg-cover" id="blog-post" style=" height: 300px;">
        <div style="position: relative; top: 50%; transform: translateY(-50%); text-align: center;" data-aos="zoom-in"
            data-aos-duration="3000">
            <h1 class="text-white" data-aos="fade-down" data-aos-duration="3000">
                Gallery
            </h1>
            <div class="container my-3 ">
                <div class="row ">
                    <div class="col-12 text-center " data-aos="fade-up" data-aos-duration="3000">
                        <a href="#" class="text-white"> Home &nbsp; &#187; &nbsp;</a>
                        <a href="#" class="text-white">Gallery &nbsp; &#187; &nbsp; </a>
                        <a href="#" class="text-white">Gallery Detail</a>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<div class="row border border-bottom-0 border-start-0 border-end-0 border-5 p-3">
    <div class="col-md-12">
        <section id="portfolio-details" class="portfolio-details">
            <div class="container">
                <?php 
$encode = $_GET['id'];
$id = base64_decode($encode);


$sql = "SELECT * FROM gallery WHERE course_id=?";
$result = $con->prepare($sql);
$result->execute([$id]);
$result_fetch_data = $result->fetchAll(PDO::FETCH_ASSOC);

foreach ($result_fetch_data as $row) { 
    $images = explode(',', $row['images']);
    $firstImage = true; ?>
                <div class="row border border-top-0 border-start-0 border-end-0 border-5 p-3">
                    <div class="col-lg-8" data-aos="fade-down" data-aos-duration="3000">
                        <div class="portfolio-details-slider swiper">
                            <div id="carouselBasicExample<?php echo $row['id']; ?>" class="carousel slide carousel-fade"
                                data-bs-ride="carousel">
                                <div class="carousel-indicators">
                                    <?php foreach ($images as $key => $row_images) { ?>
                                    <button type="button"
                                        data-bs-target="#carouselBasicExample<?php echo $row['id']; ?>"
                                        data-bs-slide-to="<?php echo $key; ?>"
                                        class="<?php echo ($key === 0) ? 'active' : ''; ?>"
                                        aria-current="<?php echo ($key === 0) ? 'true' : 'false'; ?>"
                                        aria-label="Slide <?php echo $key + 1; ?>"></button>
                                    <?php } ?>
                                </div>

                                <div class="carousel-inner">
                                    <?php foreach ($images as $key => $row_images) { ?>
                                    <div class="carousel-item<?php echo ($key === 0) ? ' active' : ''; ?>">
                                        <img src="admin/uploads/<?php echo $row_images; ?>" class="d-block img-fluid"
                                            alt="Image" style="height: 400px;" />
                                    </div>
                                    <?php } ?>
                                </div>

                                <button class="carousel-control-prev" type="button"
                                    data-bs-target="#carouselBasicExample<?php echo $row['id']; ?>"
                                    data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button"
                                    data-bs-target="#carouselBasicExample<?php echo $row['id']; ?>"
                                    data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        </div>

                        <h3 class="mt-4" data-aos="fade-up" data-aos-duration="3000"><?php echo $row['student_name']; ?>
                        </h3>
                        <p data-aos="fade-up" data-aos-duration="3000"><?php echo $row['description']; ?></p>
                    </div>

                    <div class="col-lg-4" data-aos="fade-left" data-aos-duration="3000">
                        <div class="portfolio-info h-100">
                            <h3>Student information</h3>
                            <ul>
                                <?php
                                    $course_id = $row['course_id'];
                                    $course = "SELECT * FROM courses WHERE id=?";
                                    $course_result = $con -> prepare($course);
                                    $course_result -> execute([$course_id]);
                                    $course_name = $course_result -> fetch(PDO::FETCH_ASSOC);
                                    $name = $course_name['course_name'];
                                
                                ?>
                                <li><strong>Course</strong>: <?php echo $name; ?> </li>
                                <li><strong>Job</strong>: <?php echo $row['job']; ?></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <?php 
    } 
        ?>


            </div>
        </section>
    </div>
</div>












<?php include "inc/footer.php" ?>